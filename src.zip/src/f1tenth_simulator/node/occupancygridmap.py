#!/usr/bin/env python

import numpy as np
import sys
import cv2
import time
import rospy
import tf2_ros
import math


from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry, OccupancyGrid
from ackermann_msgs.msg import AckermannDriveStamped, AckermannDrive


class OccupancyGridMap:
    def __init__(self):
        #Topics & Subs, Pubs
        # Read paramters form params.yaml
        lidarscan_topic =rospy.get_param('~scan_topic')
        odom_topic="/odom"
        self.map_topic =rospy.get_param('~map_topic')

        self.t_prev=rospy.get_time()
        self.max_lidar_range=rospy.get_param('~scan_range')
        self.scan_beams=rospy.get_param('~scan_beams')
        
        self.base_link_x = 0
        self.base_link_y = 0
        self.base_link_yaw = 0
        # Read the map parameters from *.yaml file
        self.map_res = rospy.get_param('~map_res')
        self.map_width = rospy.get_param('~map_width')
        self.map_height = rospy.get_param('~map_height')
        self.map_p_occ = rospy.get_param('~p_occ')
        self.map_p_free = rospy.get_param('~p_free')
        self.object_size = rospy.get_param('~object_size')
        
        self.map_occ_grid_msg = OccupancyGrid()

        # Initialize the map meta info in the Occupancy Grid Message, e.g., frame_id, stamp, resolution, width, height, etc.
        self.map_occ_grid_msg.header.stamp = rospy.Time.now()
        self.map_occ_grid_msg.header.frame_id = "odom"
        self.map_occ_grid_msg.info.resolution = self.map_res
        self.map_occ_grid_msg.info.width = self.map_width
        self.map_occ_grid_msg.info.height = self.map_height
        self.map_occ_grid_msg.info.origin.position.x = -self.map_width * self.map_res / 2.0
        self.map_occ_grid_msg.info.origin.position.y = -self.map_height * self.map_res / 2.0
        
        self.map_occ_grid_msg.info.origin.orientation.x = 0
        self.map_occ_grid_msg.info.origin.orientation.y = 0
        self.map_occ_grid_msg.info.origin.orientation.z = 0
        self.map_occ_grid_msg.info.origin.orientation.w = 1.0
        
        # Initialize the cell occuopancy probabilites to 0.5 (unknown) with all cell data in Occupancy Grid Message set to unknown 
        self.occupancy_grid = np.full((int(self.map_width), int(self.map_height)), -1, dtype=np.int8)
        self.grid = self.occupancy_grid.ravel().tolist()
        self.map_occ_grid_msg.data = self.grid
    
        # Subscribe to Lidar scan and odomery topics with corresponding lidar_callback() and odometry_callback() functions 
        # ...
        rospy.Subscriber(lidarscan_topic, LaserScan, self.lidar_callback)
        rospy.Subscriber(odom_topic, Odometry, self.odom_callback)
        
        # Create a publisher for the Occupancy Grid Map
        # ...
        self.map_pub = rospy.Publisher(self.map_topic, OccupancyGrid, queue_size=10)


    # lidar_callback () uses the current LiDAR scan and Wheel Odometry data to uddate and publish the Grid Occupancy map 
    
    def lidar_callback(self, data):
        # ...
        grid_x = self.map_width
        grid_y = self.map_height
        lidar_x = math.cos(self.base_link_yaw) * 0.01286 + self.base_link_x
        lidar_y = math.sin(self.base_link_yaw) * 0.01286 + self.base_link_y
        lidar_yaw = self.base_link_yaw + math.pi
        
        for j in range(int(grid_y)):
            for i in range(int(grid_x)):
                grid_x_pos = (-0.5*self.map_width + i + 0.5) * self.map_res
                grid_y_pos = (-0.5*self.map_height + j + 0.5) * self.map_res
                
                grid_angle = math.atan2(grid_y_pos - lidar_y, grid_x_pos - lidar_x) - lidar_yaw
                grid_angle = grid_angle % (2*math.pi)
                grid_distance = math.sqrt((grid_x_pos-lidar_x)**2 + (grid_y_pos-lidar_y)**2)
                
                grid_index = int(grid_angle / data.angle_increment)
                #print("Grid Index", grid_index)
                if (grid_angle / data.angle_increment - grid_index) > 0.5:
                    grid_index = grid_index + 1
                if grid_index >= self.scan_beams:
                    grid_index = 0 
                
                
                r = data.ranges[grid_index]
                theta = grid_index*data.angle_increment
                
                x_lidar_hit = r*math.cos(theta)
                y_lidar_hit = r*math.sin(theta)
                x_odom_hit = lidar_x + x_lidar_hit*math.cos(lidar_yaw) - y_lidar_hit*math.sin(lidar_yaw)
                y_odom_hit = lidar_y + x_lidar_hit*math.sin(lidar_yaw) + y_lidar_hit*math.cos(lidar_yaw)
                
                """ print("r",r)
                print("odom hit", x_odom_hit,"y", y_odom_hit)
                print("grid x, grid y", grid_x_pos,"y", grid_y_pos)
                print(r < data.range_max)
                print((abs(x_odom_hit - grid_x_pos) <= 0.5 * (self.object_size + self.map_res)))
                print(abs(y_odom_hit - grid_y_pos) <= 0.5 * (self.object_size + self.map_res))
                 """      
                
                if (r < 12) and ((abs(x_odom_hit - grid_x_pos) <= 0.5*(self.object_size + self.map_res)) and (abs(y_odom_hit - grid_y_pos) <= 0.5*(self.object_size + self.map_res))):
                    self.occupancy_grid[j][i] = min(self.occupancy_grid[j][i] + 1, 100)
                    #print("is this shit working")
                elif (r < 12) and(grid_distance < r):
                    self.occupancy_grid[j][i] = max(self.occupancy_grid[j][i] - 1, -100)
                    #print("what about this shit")
                
                p_mij = 1 - 1 / (1 + math.exp(self.occupancy_grid[j][i]))

                if p_mij >= 0.8:
                    self.map_occ_grid_msg.data[j*self.map_width + i] = 100
                elif p_mij <= 0.2:
                    self.map_occ_grid_msg.data[j*self.map_width + i] = 0
                else:
                    self.map_occ_grid_msg.data[j*self.map_width + i] = -1
                
                
                """ #print("i, j:",i,j)
                
                #print("Data:", data.ranges[grid_index])
                print("Distance to Grid:", grid_distance)
                #rint("\n")
                print("Probability",p_mij) """
                
                #print(self.grid)
                """ # if  lidar distance is == grid distance its occupied
                if (data.ranges[grid_index] > int(grid_distance - math.sqrt(2)*self.map_res)) and (data.ranges[grid_index] < int(grid_distance + math.sqrt(2)*self.map_res)):
                    self.grid[int(j*grid_x + i)] = 100
                    print("occupied", self.grid[int(j*grid_x + i)])
                # if lidar distance is < grid distance its unknown
                elif data.ranges[grid_index] < int(grid_distance):
                    self.grid[int(j*grid_x + i)] = -1
                    print("unknown", self.grid[int(j*grid_x + i)])
                # if lidar distance is > grid Distance its free
                elif data.ranges[grid_index] > int(grid_distance):
                    self.grid[int(j*grid_x + i)] = 0
                    print("free", self.grid[int(j*grid_x + i)])
                
                print(self.grid) """
                
                # Publish to map topic
                #self.map_occ_grid_msg.data = self.occupancy_grid
                self.map_occ_grid_msg.header.stamp = rospy.Time.now()
                self.map_pub.publish(self.map_occ_grid_msg)        
        

    # odom_callback() retrives the wheel odometry data from the publsihed odom_msg
    def odom_callback(self, odom_msg):
    # ...
        self.vehicle_pose_x = odom_msg.pose.pose.position.x
        self.vehicle_pose_y = odom_msg.pose.pose.position.y
        
        self.sin_yaw = odom_msg.pose.pose.orientation.z
        self.cos_yaw = odom_msg.pose.pose.orientation.w
        self.base_link_yaw = 2 * math.atan2(self.sin_yaw, self.cos_yaw)
        if self.base_link_yaw < 0:
            self.base_link_yaw = 2 * math.pi + self.base_link_yaw
        

def main(args):
    rospy.init_node("occupancygridmap", anonymous=True)
    OccupancyGridMap()
    rospy.sleep(0.1)
    rospy.spin()

if __name__=='__main__':
	main(sys.argv)

