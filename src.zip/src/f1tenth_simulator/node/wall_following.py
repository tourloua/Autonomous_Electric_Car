#!/usr/bin/env python
from __future__ import print_function
import sys
import math
import numpy as np
import time

#ROS Imports
import rospy
from sensor_msgs.msg import LaserScan
from ackermann_msgs.msg import AckermannDriveStamped, AckermannDrive
from nav_msgs.msg import Odometry


class WallFollow:
    def __init__(self):

        # Read the Wall-Following controller paramters form params.yaml
        # ...
        # Topic Names
        lidarscan_topic =rospy.get_param('~scan_topic')
        odom_topic = rospy.get_param('~odom_topic')
        drive_topic = rospy.get_param('~drive_topic')
    
        # Get Parameters
        self.scan_beams=rospy.get_param('~scan_beams')
        self.max_steering_angle=rospy.get_param('~max_steering_angle')
        self.max_lidar_range=rospy.get_param('~scan_range')
        self.wheelbase=rospy.get_param('~wheelbase')
        self.k_p=rospy.get_param('~k_p')
        self.k_d=rospy.get_param('~k_d')
        self.car_velocity=rospy.get_param('~car_velocity')
        self.stop_distance=rospy.get_param('~stop_distance')
        self.distance_decay=rospy.get_param('~distance_decay')
        self.viewing_angle=rospy.get_param('~viewing_angle')
        
        self.angle_bl = 4.71239 #270
        self.angle_br = 1.57079 # 90
        self.angle_al = 3.83972 #220
        self.angle_ar = 2.44346 # 140
        
        self.theta_l= float(self.angle_bl - self.angle_al)
        self.theta_r= float(self.angle_ar - self.angle_br)
        
        # Subscrbie to LiDAR scan Wheel Odometry topics. This is to read the LiDAR scan data and vehicle actual velocity
        rospy.Subscriber(lidarscan_topic, LaserScan, self.lidar_callback,queue_size=1)
        rospy.Subscriber(odom_topic, Odometry, self.odom_callback,queue_size=1)

        # Create a publisher for the Drive topic
        self.drive_pub =rospy.Publisher(drive_topic, AckermannDriveStamped, queue_size=1)
        

    # The LiDAR callback function is where you read LiDAR scan data as it becomes availble and compute the vehile veloicty and steering angle commands
    
    def lidar_callback(self, data):      
        
        # Exttract the parameters of two walls on the left and right side of the vehicles. Referrring to Fig. 1 in the lab instructions, these are al, bl, thethal, ... 
        # ...
        index = int(round(self.angle_al/data.angle_increment))
        dis_laser_al = data.ranges[index]
        if dis_laser_al >= self.max_lidar_range:
            dis_laser_al = self.max_lidar_range
        
        index = int(round(self.angle_bl/data.angle_increment))
        dis_laser_bl = data.ranges[index]
        if dis_laser_bl >= self.max_lidar_range:
            dis_laser_bl = self.max_lidar_range
        
        index = int(round(self.angle_ar/data.angle_increment))
        dis_laser_ar = data.ranges[index]
        if dis_laser_ar >= self.max_lidar_range:
            dis_laser_ar = self.max_lidar_range    
        
        index = int(round(self.angle_br/data.angle_increment))
        dis_laser_br = data.ranges[index]
        if dis_laser_br >= self.max_lidar_range:
            dis_laser_br = self.max_lidar_range
        
        beta_l = float(math.atan((dis_laser_al*math.cos(self.theta_l)-dis_laser_bl)/(dis_laser_al*math.sin(self.theta_l))))
        beta_r = float(math.atan((dis_laser_ar*math.cos(self.theta_r)-dis_laser_br)/(dis_laser_ar*math.sin(self.theta_r))))
        
        alpha_l = float(-beta_l + (3*math.pi/2) - self.angle_bl)
        alpha_r = float(beta_r + (math.pi/2) - self.angle_br)
        
        dis_l = dis_laser_bl*math.cos(beta_l)
        dis_r = dis_laser_br*math.cos(beta_r)
        
        # Compute the steering angle command to maintain the vehicle in the middle of left and and right walls
        # ... 
        if self.vel >= 0.01 or self.vel <= -0.01:
            d_tilda_lr = dis_l-dis_r
            d_dot_lr = -self.vel*math.sin(alpha_l) - self.vel*math.sin(alpha_r)
            delta = math.atan((-self.wheelbase*(-self.k_p*d_tilda_lr - self.k_d*d_dot_lr))/((self.vel**2)*(math.cos(alpha_r)+math.cos(alpha_l))))
        else:
            delta = 0 
        
        if delta > self.max_steering_angle:
            delta = self.max_steering_angle
        elif delta < -self.max_steering_angle:
            delta = -self.max_steering_angle
        
        # Find the closest obstacle point within a narrow viewing angle in front of the vehicle and compute the vehicle velocity command accordingly
        #  ...
        closest_dis = min(data.ranges[-int((self.viewing_angle/data.angle_increment))+int(self.scan_beams/2):int((self.viewing_angle/data.angle_increment))+int(self.scan_beams/2)])
        des_vel = self.car_velocity*(1-math.exp(-max(closest_dis-self.stop_distance,0)/self.distance_decay))     


        # Publish steering angle and velocity commnads to the Drive topic
        # ...
        self.drive_msg = AckermannDriveStamped()
        self.drive_msg.header.stamp = rospy.Time.now()
        self.drive_msg.header.frame_id = "base_link"           
        self.drive_msg.drive.steering_angle = delta
        self.drive_msg.drive.speed = des_vel

        self.drive_pub.publish(self.drive_msg)

    # The Odometry callback reads the actual vehicle velocity from VESC. 
    def odom_callback(self, odom_msg):
        # update current speed
        self.vel = odom_msg.twist.twist.linear.x

def main(args):
    rospy.init_node("WallFollow_node", anonymous=True)
    wf = WallFollow()
    rospy.sleep(0.1)
    rospy.spin()

if __name__=='__main__':
	main(sys.argv)
